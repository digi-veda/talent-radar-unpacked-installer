Talent Radar Chrome Extension - Unpacked Installer

This zip contains extension files only.

For customer install and upgrade scripts, use:
https://github.com/digi-veda/talent-radar-unpacked-installer/tree/main/scripts
